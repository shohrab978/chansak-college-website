import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import {Menu, X, ArrowRight, BookOpen, GraduationCap, Bell, Building2, Globe2, MapPin, Phone, Mail, CalendarDays, Users, LibraryBig} from 'lucide-react';
import './style.css';

const copy = {
 en: {
  nav:['Home','About','Academics','Departments','Notices','Contact'],
  eyebrow:'WELCOME TO', title:'Chandpur Government College', subtitle:'A place to learn, discover and shape the future.',
  explore:'Explore the college', notices:'Latest notices', all:'View all notices', about:'About the college',
  aboutText:'Chandpur Government College is a centre for learning and academic development in Chandpur. Explore the college, its academic activities and campus resources.',
  academics:'Academic life', academicsText:'Learning opportunities, academic resources and student support.',
  departments:'Departments', departmentsText:'Explore academic disciplines and subject areas.',
  noticeText:'Important announcements and updates will appear here.',
  contact:'Contact information', contactText:'Verified contact details will be added by the college authority.',
  quick:'Quick links', address:'Chandpur, Bangladesh', placeholder:'Information will be updated soon'
 },
 bn: {
  nav:['হোম','কলেজ পরিচিতি','শিক্ষাকার্যক্রম','বিভাগসমূহ','নোটিশ','যোগাযোগ'],
  eyebrow:'স্বাগতম', title:'চাঁদপুর সরকারি কলেজ', subtitle:'জ্ঞান, শিক্ষা ও সম্ভাবনার পথে একসঙ্গে।',
  explore:'কলেজ সম্পর্কে জানুন', notices:'সাম্প্রতিক নোটিশ', all:'সব নোটিশ', about:'কলেজ পরিচিতি',
  aboutText:'চাঁদপুর সরকারি কলেজ চাঁদপুরের একটি শিক্ষাপ্রতিষ্ঠান। কলেজ, শিক্ষাকার্যক্রম ও ক্যাম্পাস-সংক্রান্ত তথ্য এখানে পাওয়া যাবে।',
  academics:'শিক্ষাকার্যক্রম', academicsText:'শিক্ষার সুযোগ, একাডেমিক সম্পদ ও শিক্ষার্থী সহায়তা।',
  departments:'বিভাগসমূহ', departmentsText:'বিভিন্ন শিক্ষাবিষয় ও বিভাগ সম্পর্কে জানুন।',
  noticeText:'গুরুত্বপূর্ণ ঘোষণা ও হালনাগাদ তথ্য এখানে প্রকাশিত হবে।',
  contact:'যোগাযোগের তথ্য', contactText:'যাচাইকৃত যোগাযোগের তথ্য পরে যুক্ত করা হবে।',
  quick:'দ্রুত লিংক', address:'চাঁদপুর, বাংলাদেশ', placeholder:'তথ্য শিগগিরই হালনাগাদ করা হবে'
 }
};
function App(){
 const [lang,setLang]=useState('en'), [open,setOpen]=useState(false); const t=copy[lang];
 const sections=['home','about','academics','departments','notices','contact'];
 const cards=[
  {icon:BookOpen,title:lang==='en'?'Academic programmes':'শিক্ষাকার্যক্রম',desc:t.academicsText},
  {icon:Users,title:lang==='en'?'Student community':'শিক্ষার্থী সমাজ',desc:lang==='en'?'A welcoming environment for learning and participation.':'শেখা ও অংশগ্রহণের জন্য একটি সহায়ক পরিবেশ।'},
  {icon:LibraryBig,title:lang==='en'?'Learning resources':'শিক্ষা-সহায়ক সম্পদ',desc:lang==='en'?'Resources to support study and academic growth.':'পড়াশোনা ও শিক্ষার অগ্রগতিতে সহায়ক সম্পদ।'}
 ];
 return <><header className="header"><div className="wrap navrow"><a className="brand" href="#home"><div className="crest">চাঁসক</div><div><b>{lang==='en'?'Chandpur Government College':'চাঁদপুর সরকারি কলেজ'}</b><small>{lang==='en'?'CHANDPUR, BANGLADESH':'চাঁদপুর, বাংলাদেশ'}</small></div></a><nav className={open?'nav open':'nav'}>{t.nav.map((n,i)=><a key={n} href={'#'+sections[i]} onClick={()=>setOpen(false)}>{n}</a>)}</nav><div className="actions"><button className="lang" onClick={()=>setLang(lang==='en'?'bn':'en')}><Globe2 size={16}/>{lang==='en'?'বাংলা':'English'}</button><button className="menu" onClick={()=>setOpen(!open)} aria-label="Toggle menu">{open?<X/>:<Menu/>}</button></div></div></header>
 <main><section id="home" className="hero"><div className="hero-shape"></div><div className="wrap hero-inner"><div className="hero-copy"><span className="eyebrow">{t.eyebrow}</span><h1>{t.title}</h1><p>{t.subtitle}</p><a className="primary" href="#about">{t.explore}<ArrowRight size={18}/></a></div><div className="hero-art"><div className="art-circle"><Building2 size={94} strokeWidth={1}/><span>CGC</span></div><div className="art-caption">{lang==='en'?'LEARN • GROW • ACHIEVE':'শিখি • গড়ি • এগিয়ে যাই'}</div></div></div></section>
 <section className="stats"><div className="wrap statgrid"><div><GraduationCap/><b>—</b><span>{lang==='en'?'Academic programmes':'শিক্ষাকার্যক্রম'}</span></div><div><Users/><b>—</b><span>{lang==='en'?'Students':'শিক্ষার্থী'}</span></div><div><Building2/><b>—</b><span>{lang==='en'?'Departments':'বিভাগ'}</span></div><div><CalendarDays/><b>—</b><span>{lang==='en'?'Established':'প্রতিষ্ঠাকাল'}</span></div></div></section>
 <section id="about" className="section"><div className="wrap split"><div><span className="kicker">01 / {t.nav[1]}</span><h2>{t.about}</h2><p className="lead">{t.aboutText}</p><a className="textlink" href="#contact">{lang==='en'?'Get in touch':'যোগাযোগ করুন'} <ArrowRight size={17}/></a></div><div className="about-panel"><div className="panel-mark">চাঁসক</div><h3>{lang==='en'?'Education for tomorrow':'আগামীর জন্য শিক্ষা'}</h3><p>{lang==='en'?'Knowledge • Integrity • Excellence':'জ্ঞান • সততা • উৎকর্ষ'}</p></div></div></section>
 <section id="academics" className="section pale"><div className="wrap"><span className="kicker">02 / {t.nav[2]}</span><h2>{t.academics}</h2><p className="lead">{t.academicsText}</p><div className="cardgrid">{cards.map((c,i)=><article className="feature" key={i}><div className="feature-icon"><c.icon/></div><h3>{c.title}</h3><p>{c.desc}</p></article>)}</div></div></section>
 <section id="departments" className="section"><div className="wrap"><span className="kicker">03 / {t.nav[3]}</span><h2>{t.departments}</h2><p className="lead">{t.departmentsText}</p><div className="emptyline">{t.placeholder}</div></div></section>
 <section id="notices" className="section pale"><div className="wrap"><div className="sectionhead"><div><span className="kicker">04 / {t.nav[4]}</span><h2>{t.notices}</h2></div><a className="textlink" href="#notices">{t.all} <ArrowRight size={17}/></a></div><div className="notice"><div className="noticeicon"><Bell/></div><div><b>{t.placeholder}</b><p>{t.noticeText}</p></div><span className="date">—</span></div></div></section>
 <section id="contact" className="section"><div className="wrap"><span className="kicker">05 / {t.nav[5]}</span><h2>{t.contact}</h2><p className="lead">{t.contactText}</p><div className="contactgrid"><div><MapPin/><b>{t.address}</b><span>{lang==='en'?'College address':'কলেজের ঠিকানা'}</span></div><div><Phone/><b>{t.placeholder}</b><span>{lang==='en'?'Telephone':'টেলিফোন'}</span></div><div><Mail/><b>{t.placeholder}</b><span>{lang==='en'?'Email':'ইমেইল'}</span></div></div></div></section></main>
 <footer><div className="wrap foot"><div className="brand footbrand"><div className="crest">চাঁসক</div><div><b>{lang==='en'?'Chandpur Government College':'চাঁদপুর সরকারি কলেজ'}</b><small>{t.address}</small></div></div><div className="footright"><span>© {new Date().getFullYear()} {lang==='en'?'Chandpur Government College':'চাঁদপুর সরকারি কলেজ'}</span><span>{t.quick}: {t.nav.slice(0,3).join(' · ')}</span></div></div></footer></>
}
createRoot(document.getElementById('root')).render(<App/>);
